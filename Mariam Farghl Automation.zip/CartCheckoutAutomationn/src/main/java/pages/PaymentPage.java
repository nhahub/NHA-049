package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPage extends BasePage {

    @FindBy(name = "name_on_card")
    private WebElement nameInput;

    @FindBy(name = "card_number")
    private WebElement cardInput;

    @FindBy(name = "cvc")
    private WebElement cvcInput;

    @FindBy(name = "expiry_month")
    private WebElement monthInput;

    @FindBy(name = "expiry_year")
    private WebElement yearInput;

    @FindBy(xpath = "//button[@data-qa='pay-button']")
    private WebElement payBtn;

    @FindBy(xpath = "//p[contains(text(),'Congratulations')]")
    private WebElement successMsg;

    public PaymentPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void fillPaymentDetails(String name, String card, String cvc, String month, String year) {
        sendKeys(nameInput, name);
        sendKeys(cardInput, card);
        sendKeys(cvcInput, cvc);
        sendKeys(monthInput, month);
        sendKeys(yearInput, year);
    }

    public void clickPay() {
        click(payBtn);
        sleep(3000);
    }

    public boolean isOrderSuccessful() {
        return isDisplayed(successMsg);
    }
}