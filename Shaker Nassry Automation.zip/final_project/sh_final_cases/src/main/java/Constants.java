
import org.openqa.selenium.WebDriver;

public class Constants {
    public static WebDriver driver;
    public static final String WEBSITE_URL = "https://admin-demo.nopcommerce.com/login?returnUrl=%2FAdmin%2FProduct%2FList";
    public static final String Product_URL = "https://admin-demo.nopcommerce.com/Admin/Product/List";
    public static final String EMAIL = "admin@yourstore.com";
    public static final String PASSWORD = "admin";
}
