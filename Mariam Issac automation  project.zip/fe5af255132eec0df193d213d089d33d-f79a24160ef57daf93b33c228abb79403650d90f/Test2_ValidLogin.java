import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Test2_ValidLogin {

    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://automationexercise.com/");
        driver.manage().window().maximize();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("mariam.test@gmail.com");
        driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("DEPI@2025");
        driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();
        Thread.sleep(3000);

        driver.quit();
    }
}