package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductsPage extends BasePage {

    @FindBy(xpath = "//button[contains(text(),'Continue Shopping')]")
    private WebElement continueShoppingBtn;

    @FindBy(xpath = "//div[@class='modal-content']//a[contains(text(),'View Cart')]")
    private WebElement viewCartLinkModal;

    public ProductsPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void addProductToCartByIndex(int index) {
        sleep(1500);
        js.executeScript("window.scrollBy(0,400)");
        sleep(1000);

        WebElement addBtn = driver.findElement(
                By.xpath("(//div[@class='productinfo text-center']//a[contains(@class,'add-to-cart')])[" + index + "]")
        );
        js.executeScript("arguments[0].click();", addBtn);
        sleep(2500);
    }

    public void clickContinueShopping() {
        try {
            WebElement continueBtn = driver.findElement(
                    By.xpath("//button[contains(text(),'Continue Shopping')]")
            );
            js.executeScript("arguments[0].click();", continueBtn);
            sleep(1500);
        } catch (Exception e) {
            System.out.println("Continue Shopping button not found, continuing...");
        }
    }

    public CartPage clickViewCart() {
        try {
            // Try to click View Cart in the modal first
            WebElement viewCartBtn = driver.findElement(
                    By.xpath("//div[@class='modal-content']//a[contains(text(),'View Cart')]")
            );
            js.executeScript("arguments[0].click();", viewCartBtn);
        } catch (Exception e) {
            // If modal not found, click the main cart link
            WebElement cartLink = driver.findElement(
                    By.xpath("//a[contains(@href,'view_cart')]")
            );
            js.executeScript("arguments[0].click();", cartLink);
        }
        sleep(2000);
        return new CartPage(driver);
    }
}