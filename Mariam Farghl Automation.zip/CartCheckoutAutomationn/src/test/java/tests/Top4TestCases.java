package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Top4TestCases extends BaseTest {

    // TC_001: Add single product to cart
    @Test(priority = 1, description = "TC_001: Add single product to cart")
    public void testAddSingleProduct() {
        System.out.println("\n========== TC_001: Add Single Product ==========");

        productsPage = homePage.goToProducts();
        productsPage.addProductToCartByIndex(1);
        cartPage = productsPage.clickViewCart();

        int itemCount = cartPage.getCartItemsCount();
        System.out.println("Cart items count: " + itemCount);

        Assert.assertTrue(itemCount >= 1, "Cart should contain at least 1 item");
        System.out.println("✅ PASSED: Single product added successfully\n");
    }

    // TC_002: Add multiple products to cart
    @Test(priority = 2, description = "TC_002: Add multiple products to cart")
    public void testAddMultipleProducts() {
        System.out.println("\n========== TC_002: Add Multiple Products ==========");

        productsPage = homePage.goToProducts();

        // Add first product
        productsPage.addProductToCartByIndex(1);
        productsPage.clickContinueShopping();

        // Add second product
        productsPage.addProductToCartByIndex(2);
        cartPage = productsPage.clickViewCart();

        int itemCount = cartPage.getCartItemsCount();
        System.out.println("Cart items count: " + itemCount);

        Assert.assertTrue(itemCount >= 2, "Cart should contain at least 2 items");
        System.out.println("✅ PASSED: Multiple products added successfully\n");
    }

    // TC_004: Remove product from cart
    @Test(priority = 3, description = "TC_004: Remove product from cart")
    public void testRemoveProduct() {
        System.out.println("\n========== TC_004: Remove Product From Cart ==========");

        // Add product first
        productsPage = homePage.goToProducts();
        productsPage.addProductToCartByIndex(1);
        cartPage = productsPage.clickViewCart();

        int initialCount = cartPage.getCartItemsCount();
        System.out.println("Initial cart items: " + initialCount);

        // Remove product
        cartPage.removeFirstProduct();

        int finalCount = cartPage.getCartItemsCount();
        System.out.println("Final cart items: " + finalCount);

        Assert.assertTrue(finalCount < initialCount, "Item should be removed from cart");
        System.out.println("✅ PASSED: Product removed successfully\n");
    }

    // TC_012: Registered user complete checkout
    @Test(priority = 4, description = "TC_012: Registered user complete checkout")
    public void testRegisteredUserCheckout() {
        System.out.println("\n========== TC_012: Registered User Checkout ==========");

        // Login with Mariam's credentials
        loginPage = homePage.goToLogin();
        loginPage.login("mariamfarghl17@gmail.com", "Roma1792000@");

        // Add product
        productsPage = homePage.goToProducts();
        productsPage.addProductToCartByIndex(1);
        cartPage = productsPage.clickViewCart();

        // Checkout
        checkoutPage = cartPage.proceedToCheckout();
        checkoutPage.addComment("Please deliver after 6 PM");

        // Payment
        paymentPage = checkoutPage.placeOrder();
        paymentPage.fillPaymentDetails("Mariam Farghl", "4111609365311791", "123", "12", "2030");
        paymentPage.clickPay();

        boolean isSuccess = paymentPage.isOrderSuccessful();
        System.out.println("Order successful: " + isSuccess);

        Assert.assertTrue(isSuccess, "Order should be placed successfully");
        System.out.println("✅ PASSED: Checkout completed successfully\n");
    }
}