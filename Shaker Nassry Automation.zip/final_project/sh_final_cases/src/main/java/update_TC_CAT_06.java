import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class update_TC_CAT_06 {
    String productName ;

    public static void deleteProduct(String productName) throws InterruptedException {
        Constants.driver = new ChromeDriver();
        Constants.driver.navigate().to("https://admin-demo.nopcommerce.com/Admin/Product/List");
        Constants.driver.manage().window().maximize();

        Constants.driver.findElement(By.id("SearchProductName")).sendKeys(productName);
        Constants.driver.findElement(By.cssSelector("a[href='/Admin/Product/Edit/1']")).click();

        Constants.driver.findElement(By.id("Name")).clear();
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Name")).sendKeys("UPDATED NAME LAPTOP _ TEST");
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Price")).clear();
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Price")).sendKeys("100");
        Thread.sleep(1000);
        Constants.driver.findElement(By.tagName("Save")).click();
    }
}
