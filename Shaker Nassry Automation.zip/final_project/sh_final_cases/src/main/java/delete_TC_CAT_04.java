import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class delete_TC_CAT_04 {
    String productName ;

    public static void deleteProduct(String productName) throws InterruptedException {
        Constants.driver = new ChromeDriver();
        Constants.driver.navigate().to("https://admin-demo.nopcommerce.com/Admin/Product/List");
        Constants.driver.manage().window().maximize();

        Constants.driver.findElement(By.id("SearchProductName")).sendKeys(productName);
        Constants.driver.findElement(By.cssSelector("a[href='/Admin/Product/Edit/1']")).click();

        Thread.sleep(1000);
        Constants.driver.findElement(By.id("product-delete")).click();
        Thread.sleep(1000);
        Constants.driver.findElement(By.xpath("//button[text()='Delete']")).click();

    }

}
