import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class add_product_TC_CAT_02 {
    public static void main(String[] args) throws InterruptedException {
        Constants.driver = new ChromeDriver();
        Constants.driver.navigate().to("https://admin-demo.nopcommerce.com/Admin/Product/List");
        Constants.driver.manage().window().maximize();
        Constants.driver.findElement(By.cssSelector("a[href='/Admin/Product/Create']")).click();


        Constants.driver.findElement(By.id("advanced-settings-mode")).click();

        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Name")).sendKeys("NEW LAPTOP _ TEST");
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("ShortDescription")).sendKeys("DESCRIPTION LAPTOP _ TEST");
        Thread.sleep(1000);
        Constants.driver.findElement(By.cssSelector(".note-editable")).sendKeys("FULL DESCRIPTION LAPTOP _ TEST");
        Thread.sleep(1500);
        Constants.driver.findElement(By.id("Sku")).sendKeys("TEST_001");

        WebElement dropdownElement = Constants.driver.findElement(By.id("SelectedCategoryIds"));
        Select dropdown = new Select(dropdownElement);
        dropdown.selectByVisibleText("Computers");
        /*
        WebElement dropdownElement2 = Constants.driver.findElement(By.id("SelectedManufacturerIds"));
        Select dropdown2 = new Select(dropdownElement2);
        dropdown2.selectByVisibleText("HP");
        Constants.driver.findElement(By.id("SelectedProductTags")).sendKeys("LapTop_TAG");
        Constants.driver.findElement(By.id("Gtin")).sendKeys("1234");
        Constants.driver.findElement(By.id("ManufacturerPartNumber")).sendKeys("12345");
        Constants.driver.findElement(By.id("ShowOnHomepage")).click();
        Constants.driver.findElement(By.id("VisibleIndividually")).click();

        WebElement dropdownElement3 = Constants.driver.findElement(By.id("SelectedCustomerRoleIds"));
        Select dropdown3 = new Select(dropdownElement3);
        dropdown3.deselectByValue("3");
        dropdown3.deselectByValue("4");

        WebElement dropdownElement4 = Constants.driver.findElement(By.id("SelectedStoreIds"));
        Select dropdown4 = new Select(dropdownElement4);
        dropdown3.deselectByValue("1");
        */


        Constants.driver.findElement(By.id("Price")).sendKeys("55");
        Constants.driver.findElement(By.id("IsTaxExempt")).click();
        Constants.driver.findElement(By.id("IsShipEnabled")).click();
        Constants.driver.findElement(By.tagName("Save")).click();

    }
}
