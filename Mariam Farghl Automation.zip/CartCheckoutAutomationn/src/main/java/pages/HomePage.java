package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BasePage {

    @FindBy(xpath = "//a[contains(text(),'Products')]")
    private WebElement productsLink;

    @FindBy(xpath = "//a[contains(@href,'view_cart')]")
    private WebElement cartLink;

    @FindBy(xpath = "//a[contains(text(),'Signup / Login')]")
    private WebElement loginLink;

    public HomePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public ProductsPage goToProducts() {
        click(productsLink);
        sleep(2000);
        return new ProductsPage(driver);
    }

    public CartPage goToCart() {
        click(cartLink);
        sleep(1000);
        return new CartPage(driver);
    }

    public LoginPage goToLogin() {
        click(loginLink);
        sleep(1000);
        return new LoginPage(driver);
    }
}