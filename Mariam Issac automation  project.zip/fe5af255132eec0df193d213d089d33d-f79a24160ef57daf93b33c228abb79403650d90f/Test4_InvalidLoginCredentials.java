import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Test4_InvalidLoginCredentials {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("🧪 TEST 4: Verify Error Message for Invalid Credentials (Login)");

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            System.out.println("1️⃣ Opening website...");
            driver.get("https://automationexercise.com/");
            driver.manage().window().maximize();
            Thread.sleep(3000);

            System.out.println("2️⃣ Clicking Signup/Login...");
            driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
            Thread.sleep(3000);

            System.out.println("3️⃣ Entering invalid credentials...");
            String invalidEmail = "wrong@email.com";
            String invalidPassword = "wrongpassword";

            driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys(invalidEmail);
            driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys(invalidPassword);
            Thread.sleep(2000);

            System.out.println("4️⃣ Clicking Login button...");
            driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();
            Thread.sleep(5000);

            try {
                WebElement errorMessage = driver.findElement(By.xpath("//p[contains(text(),'incorrect')]"));
                if (errorMessage.isDisplayed()) {
                    System.out.println("✅ TEST 4 PASSED: Error message displayed for invalid credentials!");
                    System.out.println("   Error message: " + errorMessage.getText());
                }
            } catch (Exception e) {
                try {
                    WebElement logoutButton = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
                    if (logoutButton.isDisplayed()) {
                        System.out.println("❌ TEST 4 FAILED: Login succeeded with invalid credentials!");
                    }
                } catch (Exception ex) {
                    System.out.println("❌ TEST 4 FAILED: No error message shown for invalid credentials");
                }
            }

            Thread.sleep(3000);

        } finally {
            driver.quit();
            System.out.println("🔚 Browser closed.");
        }
    }
}