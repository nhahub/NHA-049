import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Test3_InvalidEmailRegistration {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("🧪 TEST 3: Verify Error with Invalid Email Format (Registration)");

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            System.out.println("1️⃣ Opening website...");
            driver.get("https://automationexercise.com/");
            driver.manage().window().maximize();
            Thread.sleep(3000);

            System.out.println("2️⃣ Clicking Signup/Login...");
            driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
            Thread.sleep(3000);

            System.out.println("3️⃣ Entering invalid email format...");
            String invalidEmail = "invalidemail";

            driver.findElement(By.xpath("//input[@data-qa='signup-name']")).sendKeys("Test User");
            driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(invalidEmail);
            Thread.sleep(2000);

            System.out.println("4️⃣ Clicking Signup button...");
            driver.findElement(By.xpath("//button[@data-qa='signup-button']")).click();
            Thread.sleep(5000);

            try {
                WebElement signupForm = driver.findElement(By.xpath("//input[@data-qa='signup-email']"));
                String currentUrl = driver.getCurrentUrl();

                if (signupForm.isDisplayed() && currentUrl.contains("login")) {
                    System.out.println("✅ TEST 3 PASSED: Registration blocked for invalid email format!");
                    System.out.println("   Invalid email: " + invalidEmail);
                } else {
                    System.out.println("❌ TEST 3 FAILED: Form accepted invalid email format");
                }
            } catch (Exception e) {
                System.out.println("❌ TEST 3 FAILED: Unexpected behavior");
            }

            Thread.sleep(3000);

        } finally {
            driver.quit();
            System.out.println("🔚 Browser closed.");
        }
    }
}