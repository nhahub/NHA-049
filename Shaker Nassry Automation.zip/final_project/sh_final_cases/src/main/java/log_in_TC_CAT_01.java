import dev.failsafe.internal.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class log_in_TC_CAT_01 {


    public static void main(String[] args) throws InterruptedException {
        Constants.driver = new  ChromeDriver();
        Constants.driver.navigate().to(Constants.WEBSITE_URL);
        Constants.driver.manage().window().maximize();
        Constants.driver.findElement(By.id("Email")).clear();
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Email")).sendKeys(Constants.EMAIL);
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Password")).clear();
        Thread.sleep(1000);
        Constants.driver.findElement(By.id("Password")).sendKeys(Constants.PASSWORD);
        Thread.sleep(1500);
        Constants.driver.findElement(By.cssSelector("button[type='submit']")).click();
        if(Constants.driver.getPageSource().contains("Login was unsuccessful. Please correct the errors and try again.") ){
            System.out.println("❌ LOG-IN Failed");
            Constants.driver.quit();
        }else {
            System.out.println("✅ LOG-IN Successful");
            Constants.driver.quit();
        }

    }

}
