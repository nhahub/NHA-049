import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1_ValidRegistration {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("🧪 TEST 1: Complete Registration with Valid Details");

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            // Step 1: Open website
            System.out.println("1️⃣ Opening website...");
            driver.get("https://automationexercise.com/");
            driver.manage().window().maximize();
            Thread.sleep(3000);

            // Step 2: Click Signup/Login
            System.out.println("2️⃣ Clicking Signup/Login...");
            driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
            Thread.sleep(3000);

            // Step 3: Enter valid registration details
            System.out.println("3️⃣ Entering valid registration details...");
            String name = "MariamTest";
            String email = "mariam" + System.currentTimeMillis() + "@test.com"; // Unique email

            driver.findElement(By.xpath("//input[@data-qa='signup-name']")).sendKeys(name);
            driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(email);
            Thread.sleep(2000);

            // Step 4: Click Signup button
            System.out.println("4️⃣ Clicking Signup button...");
            driver.findElement(By.xpath("//button[@data-qa='signup-button']")).click();
            Thread.sleep(5000);

            // Step 5: Check if we reached the account information form
            try {
                WebElement enterAccountInfo = driver.findElement(By.xpath("//b[contains(text(),'Enter Account Information')]"));
                if (enterAccountInfo.isDisplayed()) {
                    System.out.println("✅ Reached account information form - filling details...");

                    // Step 6: Fill account information form
                    System.out.println("5️⃣ Filling account information...");

                    // Title (Mr/Mrs)
                    driver.findElement(By.id("id_gender2")).click(); // Mrs
                    Thread.sleep(1000);

                    // Password
                    driver.findElement(By.id("password")).sendKeys("TestPassword123");
                    Thread.sleep(1000);

                    // Date of Birth
                    Select days = new Select(driver.findElement(By.id("days")));
                    days.selectByValue("15");

                    Select months = new Select(driver.findElement(By.id("months")));
                    months.selectByValue("5");

                    Select years = new Select(driver.findElement(By.id("years")));
                    years.selectByValue("1990");
                    Thread.sleep(1000);

                    // Newsletter and special offers
                    driver.findElement(By.id("newsletter")).click();
                    driver.findElement(By.id("optin")).click();
                    Thread.sleep(1000);

                    // Step 7: Fill address information
                    System.out.println("6️⃣ Filling address information...");

                    // First name and Last name
                    driver.findElement(By.id("first_name")).sendKeys("Mariam");
                    driver.findElement(By.id("last_name")).sendKeys("Test");
                    Thread.sleep(1000);

                    // Company
                    driver.findElement(By.id("company")).sendKeys("Test Company");
                    Thread.sleep(1000);

                    // Address
                    driver.findElement(By.id("address1")).sendKeys("123 Test Street");
                    driver.findElement(By.id("address2")).sendKeys("Apartment 4B");
                    Thread.sleep(1000);

                    // Country
                    Select country = new Select(driver.findElement(By.id("country")));
                    country.selectByValue("United States");
                    Thread.sleep(1000);

                    // State, City, Zipcode
                    driver.findElement(By.id("state")).sendKeys("California");
                    driver.findElement(By.id("city")).sendKeys("Los Angeles");
                    driver.findElement(By.id("zipcode")).sendKeys("90001");
                    Thread.sleep(1000);

                    // Mobile number
                    driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
                    Thread.sleep(1000);

                    // Step 8: Create account
                    System.out.println("7️⃣ Creating account...");
                    driver.findElement(By.xpath("//button[@data-qa='create-account']")).click();
                    Thread.sleep(5000);

                    // Step 9: Check if account created successfully
                    try {
                        WebElement accountCreated = driver.findElement(By.xpath("//b[contains(text(),'Account Created!')]"));
                        if (accountCreated.isDisplayed()) {
                            System.out.println("✅ TEST 1 PASSED: Account created successfully!");
                            System.out.println("   Name: " + name);
                            System.out.println("   Email: " + email);

                            // Click Continue button
                            driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();
                            Thread.sleep(3000);

                            // Verify user is logged in
                            try {
                                WebElement logoutBtn = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
                                if (logoutBtn.isDisplayed()) {
                                    System.out.println("✅ User is automatically logged in!");
                                }
                            } catch (Exception e) {
                                System.out.println("⚠️ User might not be logged in automatically");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Account creation failed at final step");
                    }

                }
            } catch (Exception e) {
                // If we didn't reach the account information form
                try {
                    WebElement emailExists = driver.findElement(By.xpath("//p[contains(text(),'Email Address already exist!')]"));
                    if (emailExists.isDisplayed()) {
                        System.out.println("❌ TEST 1 FAILED: Email already exists");
                    }
                } catch (Exception ex) {
                    System.out.println("❌ TEST 1 FAILED: Could not proceed to registration form");
                }
            }

            Thread.sleep(3000);

        } finally {
            driver.quit();
            System.out.println("🔚 Browser closed.");
        }
    }
}