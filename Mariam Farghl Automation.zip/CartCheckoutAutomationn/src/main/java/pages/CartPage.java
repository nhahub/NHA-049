package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class CartPage extends BasePage {

    @FindBy(xpath = "//tbody/tr")
    private List<WebElement> cartItems;

    @FindBy(xpath = "//a[contains(text(),'Proceed To Checkout')]")
    private WebElement checkoutBtn;

    public CartPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public int getCartItemsCount() {
        sleep(1000);
        return cartItems.size();
    }

    public void removeFirstProduct() {
        sleep(1000);
        WebElement removeBtn = driver.findElement(
                By.xpath("(//a[@class='cart_quantity_delete'])[1]")
        );
        click(removeBtn);
        sleep(2000);
    }

    public CheckoutPage proceedToCheckout() {
        click(checkoutBtn);
        sleep(2000);
        return new CheckoutPage(driver);
    }
}