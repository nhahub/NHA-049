package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage extends BasePage {

    @FindBy(xpath = "//textarea[@name='message']")
    private WebElement commentBox;

    @FindBy(xpath = "//a[contains(text(),'Place Order')]")
    private WebElement placeOrderBtn;

    public CheckoutPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void addComment(String comment) {
        sendKeys(commentBox, comment);
    }

    public PaymentPage placeOrder() {
        click(placeOrderBtn);
        sleep(1000);
        return new PaymentPage(driver);
    }
}